# Introduction_to_data_mining
This is the course named introduction to data mining in CYCU.
## Q&A 1. Introduction to Python ##
Due: 2019/09/25
